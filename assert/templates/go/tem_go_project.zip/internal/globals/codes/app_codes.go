package codes

const (
	Windows = "100"
	Linux   = "101"
	IOS     = "102"
	Webapp  = "103"
)
