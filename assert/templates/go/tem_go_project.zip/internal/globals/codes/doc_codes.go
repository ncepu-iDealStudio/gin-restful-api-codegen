package codes

const (
	DOC  = "101"
	DOCX = "102"
	PPT  = "201"
	PPTX = "202"
	XLS  = "301"
	XLSX = "302"
	PDF  = "401"
	TXT  = "501"
)
